
package tictactoe;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
// importing the features I need for the porgram

public class TICTACTOE {

    static ArrayList<Integer> playerPositions = new ArrayList <Integer>(); // putting these ArrayList here to make them global. so they are readable anywhere I called them in the code
    static ArrayList<Integer> player2Positions = new ArrayList <Integer>();// putting these ArrayList here to make them global. so they are readable anywhere I called them in the code

    public static void main(String[] args)
    {
     char [] [] gameShape = {{' ', '|', ' ', '|', ' '},
                             {'-', '+', '-', '+', '-'},
                             {' ', '|', ' ', '|', ' '},
                             {'-', '+', '-', '+', '-'},
                             {' ', '|', ' ', '|', ' '}}; // The Shape of the game
                
     Scanner input = new Scanner (System.in); 
     System.out.println("Welcome User, you can play TICTACTOE with anyone you want now using this program."); // Welcome the user
     gameforShape(gameShape);// Calling the gameShape
     
     while (true){// while statement
     
     System.out.println("Player number 1, Enter your placement between 1 and 9: ");
     int player1  = input.nextInt(); // player input 1
     while (playerPositions.contains(player1) || player2Positions.contains(player1)) // if the player inputs a number that was already picked by the second player it gives him the alert below.
     {
         System.out.println("Position taken by player number 2! Enter a correct position");// He receives this message
         player1  = input.nextInt();// and allowed to input as long as he is picking an index that was already picked.
     }
    Placement(gameShape, player1, "Player");// when he inputs on a free index it prints the X sign since he is the player number 1.
     
    gameforShape(gameShape);//and it prints the game again with the new input
    
    String result = checkWinner();// and then this is called a method where it checks if the results conditions are met. I'll explain it in the method itself
      if (result.length()>0){
        System.out.println(result);
        break;// the game ends.
      }
    System.out.println("Player number 2, Enter your placement between 1 and 9: ");
    int player2 = input.nextInt();// player input 2
    while (player2Positions.contains(player2) || playerPositions.contains(player2))// if the player inputs a number that was already picked by the second player it gives him the alert below.
     {
         System.out.println("Position taken by player number 1! Enter a correct position");// He receives this message
         player2 = input.nextInt();// and allowed to input as long as he is picking an index that was already picked.
     }
    Placement(gameShape, player2, "player2");// when he inputs on a free index it prints the X sign since he is the player number 1.
    gameforShape(gameShape);//and it prints the game again with the new input
    
    result = checkWinner();// and then this is called a method where it checks if the results conditions are met.
    if (result.length()>0){
        System.out.println(result);
        break;// the game ends.
    }
    
          
     
     }
        
    }
    public static void gameforShape(char [][] gameShape) // method to call the printing process
    {
        for (char [] row : gameShape)//Printing the gameshape using 2 for loops. For each row inside the gameshape and then 
     {
         for (char c :row)//in the second for loop it prints each symbol inside of the row.
         {
             System.out.print(c); // as u see it is a print and not a println because if it was a println it will print them all below each other
         }
         System.out.println();// and it skips a line after every row.
     }
    }
    public static void Placement(char [] [] gameShape,int pos, String user) // method to print the user input.
    {
        char symbol = ' ';// empty char slot
        if (user.equals("Player"))//if user 1 is playing
        {
            symbol = 'X';// the symbol is X
            playerPositions.add(pos);// add the X to the position the player has input.
        } 
        else if (user.equals("player2"))// else if it is player 2
        {
            symbol = 'O';//the symbol is O
            player2Positions.add(pos);// add the O to the position the player has input.
        }
        
        switch (pos){
         case 1:// in case the input was 1
             gameShape [0][0] = symbol;//Place the input on the first 2d array index which refers to [0][0].
               break;
                        case 2:// in case the input was 2
             gameShape [0][2] = symbol;//Place the input on the 2nd 2d array index which refers to [0][2].
               break;
                        case 3:// in case the input was 3
             gameShape [0][4] = symbol;//Place the input on the 3rd 2d array index which refers to [0][4].
               break;
                        case 4:// in case the input was 4
             gameShape [2][0] = symbol;//Place the input on the 4th 2d array index which refers to [2][0].
               break;
                        case 5:// in case the input was 5
             gameShape [2][2] = symbol;//Place the input on the 5th 2d array index which refers to [2][2].
               break;
                        case 6:// in case the input was 6
             gameShape [2][4] = symbol;//Place the input on the 6th 2d array index which refers to [2][4].
               break;
                        case 7:// in case the input was 7
             gameShape [4][0] = symbol;//Place the input on the 7th 2d array index which refers to [4][0].
               break;
                        case 8:// in case the input was 8
             gameShape [4][2] = symbol;//Place the input on the 8th 2d array index which refers to [4][2].
               break;
                        case 9:// in case the input was 9
             gameShape [4][4] = symbol;//Place the input on the 9th 2d array index which refers to [4][4].
               break;    
                        default:
                 break;
         }
    }
    public static String checkWinner()
    {
        List topRow = Arrays.asList(1,2,3);//in here I am putting all the winning conditions. 
        List midRow = Arrays.asList(4,5,6);// the horizontal
        List botRow = Arrays.asList(7,8,9);//the vertical
        List firstCol = Arrays.asList(1,4,7);//and the oblique conditions
        List midCol = Arrays.asList(2,5,8);
        List lastCol = Arrays.asList(3,6,9);
        List cross1 = Arrays.asList(3,5,7);
        List cross2 = Arrays.asList(1,5,9);
        
        List<List> winning = new ArrayList<List>();
        
        winning.add(topRow); // I am adding to a list what are the winning conditions. and the list called winning.
        winning.add(midRow);//that is why it is saying here winning.add. 
        winning.add(botRow);
        winning.add(firstCol);
        winning.add(midCol);
        winning.add(lastCol);
        winning.add(cross1);
        winning.add(cross2);
        
        for(List l:winning)// for each list inside of the winning list
        {
                if (playerPositions.containsAll(l))//if player1 contains all the winning condition
                {
                    System.out.println("Congratulations! Player 1 Won!");//he receives this message
                    System.exit(0);// and the program breaks.

                    
                }else if (player2Positions.containsAll(l))//if player2 contains all the winning condition
                {
                    System.out.println("Congratulations! Player 2 Won!");//he receives this message
                    System.exit(0);// and the program breaks.
                    
                }
                else if (playerPositions.size() + player2Positions.size() == 9)// if no one meet the winning conditions and there's no more indexes available
                {
                    System.out.println("It is a tie.");// then it is a tie
                    System.exit(0);// and the program breaks.
                }
        }
        
        
        
        
        return "";
    }
    
}
